// (C) Vernita Gouws, Sicily Brannen, Drake Axelrod, Group: 7 (2022) 
// Work package 0 
// Exercise 1
// Submission code: 39CQFR
#include <stdio.h> 

  // Main function in the program, no program arguments supported 
void main () { 
    printf("%s", "Hello World!\n");  // Static output string printed to console
}