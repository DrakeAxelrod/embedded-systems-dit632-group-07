// (C) Vernita Gouws, Sicily Brannen, Drake Axelrod, Group: 7 (2022) 
// Work package 0 
// Exercise 2
// Submission code: 39CQFR
#include <stdio.h> 

// Main function in the program, with the argument count and argument values as parameters
void main (int argc, char *argv[]) { 
    printf("%s %s %s%s", "Hello World!", "I'm", argv[1], ".\n");  // Output string displaying the user's input
}