// (C) Drake Axelrod, Vernita Gouws, Sicily Ann Brannen group: 07 (2022)
// Work package 2
// Exercise 2
// Submission code : M60HVAJ7

#include <stdio.h>  // functions for standard input/output
#include <stdlib.h> // for standard library functions (malloc, srand)
#include <time.h>   // included for the random seed function

//#### Constants #####
#define MAX 5

// ##### typedefs  ####
typedef struct q // double linked list node
{
    int number;     // value in this node
    struct q *next; // the next node in the list
    struct q *prev; // the previous node in the list
} REGTYPE;          // so you dont have to use struct q

// ##### Function declarations   #####
REGTYPE *random_list(void);         // declaration of method
REGTYPE *add_first(REGTYPE *, int); // declaration of method
void *iterate_list(REGTYPE *, REGTYPE *); // declaration of method
void *deallocate_list(REGTYPE *, REGTYPE *); // declaration of method

//###### Main program #######
int main(int argc, char *argv[])
{
    REGTYPE *act_post, *head = NULL; // init the head and act_post pointers

    srand(time(0));               // random seed
    head = random_list();         // call function to create initial list
    iterate_list(act_post, head); // iterate over the list and print the items

    head = add_first(head, 1337); // Test adding the new item as the list's head 
    iterate_list(act_post, head); // iterate over the list and print the items

    head = add_first(head, 1234); // Test adding another item as the list's head 
    iterate_list(act_post, head); // iterate over the list and print the items

    deallocate_list(act_post, head); // free memory
    return 0; // exit code
}

// ==== End of main ======================================
/* function to create a random list using the MAX amount of list items */
REGTYPE *random_list(void)
{
    int nr;    // set a variable and initialise it to 0
    int i = 0; // set a variable and initialise it to 0

    REGTYPE *top, *old, *item; // create three pointers to the struct type of REGTYPE
    top = NULL;                // set top to null
    while (i < MAX)            // while i is not equal to MAX
    {
        item = (REGTYPE *)malloc(sizeof(REGTYPE)); // create an item struct of type REGTYPE
        item->number = rand() % 100 + 1;           // set the item's number variable to a random integer
        item->next = NULL;                         // initialise item's next variable to null
        if (top == NULL)                           // the first run of the loop
        {
            item->prev = NULL; // initialise item's previous variable to null
            top = item;        // set top to current item
        }
        else // for every run of the loop after the first item has been set to the top
        {
            old = top;                // the old pointer is set as the current top
            while (old->next != NULL) // while there are next items in the list
            {
                old = old->next; // set old to the next item in the list
            }
            item->prev = old; // set the current item's previous variable to the old item
            old->next = item; // set the end of the list's next to the current item
        }
        i++; // increment i
    }
    return (top); // return the top of the list
}

//==========================================================
/* function to append an item to the top of the list */
REGTYPE *add_first(REGTYPE *temp, int data)
{
    REGTYPE *item = (REGTYPE *)malloc(sizeof(REGTYPE)); // create a new struct of type REGTYPE
    item->number = data; // set item's number variable to the data parameter (a random int)
    temp->prev = item; // set temp's previous variable (head passed as parameter) to the current item
    item->next = temp; // set item's next variable to the current head (parameter passed as temp)
    return item; // return item which is now the list's head
}

//==========================================================
/* function to iterate over the list, print list items, and update the active position via pointer */
void *iterate_list(REGTYPE *act_post, REGTYPE *head)
{
    int nr = 0;      // counter
    act_post = head; // set the current position to head

    while (act_post != NULL)      // while the current position is not null
    {
        printf("\n Post nr %d : %d", nr++, act_post->number); // print the nr and value of correspond node, and increment nr
        act_post = act_post->next;                            // set the position to the next item in list
    }
    printf("\n"); // clean up lines
}

//==========================================================
/* function to free the memory from allocated list items */
void *deallocate_list(REGTYPE *act_post, REGTYPE *head)
{
    // reset the position of act_post to head since act_post is at the end of list after first while loop
    while ((act_post = head) != NULL) //  while current position is not 0
    {
        head = act_post->next; // set to next position as you free each this is to make sure that you free everything
        free(act_post);        // since the head is pointing to next we can free the previous head without losing the list
    }
}
